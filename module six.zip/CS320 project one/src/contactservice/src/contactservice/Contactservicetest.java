package contactservice;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactServiceImpl();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("001", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        assertEquals(contact, contactService.getContactById("001"));
    }

    @Test
    public void testUpdateFirstName() {
        Contact contact = new Contact("002", "Jane", "Smith", "9876543210", "456 Elm St");
        contactService.addContact(contact);

        contactService.updateFirstName("002", "Alice");

        assertEquals("Alice", contactService.getContactById("002").getFirstName());
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("003", "Tom", "Jones", "5555555555", "789 Oak Ave");
        contactService.addContact(contact);

        contactService.deleteContact("003");

        assertNull(contactService.getContactById("003"));
    }

    // Add more tests for updateLastName, updatePhone, updateAddress, and additional edge cases.
}
