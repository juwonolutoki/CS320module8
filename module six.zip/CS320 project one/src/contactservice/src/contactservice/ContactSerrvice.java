package contactservice;

public interface ContactService {
    void addContact(Contact contact);
    void deleteContact(String contactId);
    void updateFirstName(String contactId, String newFirstName);
    void updateLastName(String contactId, String newLastName);
    void updatePhone(String contactId, String newPhone);
    void updateAddress(String contactId, String newAddress);
    Contact getContactById(String contactId);
}
