import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private Map<String, Task> taskMap = new HashMap<>();

    // Add a task
    public void addTask(Task task) {
        if (task == null || taskMap.containsKey(task.getId())) {
            throw new IllegalArgumentException("Task cannot be null and ID must be unique.");
        }
        taskMap.put(task.getId(), task);
    }

    // Delete a task by ID
    public void deleteTask(String id) {
        if (id == null || !taskMap.containsKey(id)) {
            throw new IllegalArgumentException("Task ID cannot be null and must exist.");
        }
        taskMap.remove(id);
    }

    // Update a task
    public void updateTask(String id, String name, String description) {
        Task task = taskMap.get(id);
        if (task == null) {
            throw new IllegalArgumentException("Task ID must exist.");
        }
        if (name != null) {
            task.setName(name);
        }
        if (description != null) {
            task.setDescription(description);
        }
    }

    // Get a task
    public Task getTask(String id) {
        return taskMap.get(id);
    }
}
