import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaskServiceTest {

    @Test
    void testAddTask() {
        TaskService service = new TaskService();
        Task task = new Task("1", "Test Task", "This is a test task.");
        service.addTask(task);

        assertEquals(task, service.getTask("1"));
    }

    @Test
    void testAddTaskDuplicateId() {
        TaskService service = new TaskService();
        Task task1 = new Task("1", "Task One", "Description One");
        Task task2 = new Task("1", "Task Two", "Description Two");

        service.addTask(task1);
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> service.addTask(task2));
        assertEquals("Task cannot be null and ID must be unique.", thrown.getMessage());
    }

    @Test
    void testUpdateTask() {
        TaskService service = new TaskService();
        Task task = new Task("1", "Initial Name", "Initial Description");
        service.addTask(task);

        service.updateTask("1", "Updated Name", "Updated Description");
        Task updatedTask = service.getTask("1");

        assertEquals("Updated Name", updatedTask.getName());
        assertEquals("Updated Description", updatedTask.getDescription());
    }

    @Test
    void testUpdateNonExistingTask() {
        TaskService service = new TaskService();
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> service.updateTask("nonexistent", "Name", "Description"));
        assertEquals("Task ID must exist.", thrown.getMessage());
    }

    @Test
    void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = new Task("1", "Task to be Deleted", "Description");
        service.addTask(task);

        service.deleteTask("1");
        assertNull(service.getTask("1"));
    }

    @Test
    void testDeleteNonExistingTask() {
        TaskService service = new TaskService();
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> service.deleteTask("nonexistent"));
        assertEquals("Task ID cannot be null and must exist.", thrown.getMessage());
    }

    @Test
    void testTaskConstructorValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("ID_TOO_LONG", "Name", "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("ID", null, "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("ID", "Name", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("ID", "Name", "Description_That_Is_Too_Long"));
    }
}
