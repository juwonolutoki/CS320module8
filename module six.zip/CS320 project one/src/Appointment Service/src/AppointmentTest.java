import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {

    @Test
    public void testValidAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000); // 10 seconds in the future
        Appointment appointment = new Appointment("1234567890", futureDate, "Meeting");

        assertNotNull(appointment);
        assertEquals("1234567890", appointment.getAppointmentID());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Meeting", appointment.getDescription());
    }

    @Test
    public void testInvalidAppointmentID() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Meeting");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Meeting");
        });
    }

    @Test
    public void testInvalidAppointmentDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 10000); // 10 seconds in the past
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", pastDate, "Meeting");
        });
    }

    @Test
    public void testInvalidDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", futureDate, null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", futureDate, "A very long description that exceeds fifty characters long and should fail.");
        });
    }
}
